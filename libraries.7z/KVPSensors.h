#include <Arduino.h>

#ifndef _KVP_Sensors_h

#define _KVP_Sensors_h

#define KEY_DELIMITER 			" "
#define KEY_VALUE_DELIMITER 	"="
#define VALUE_DELIMITER 		","
#define PORT_DELIMITER 			"."

#define DiagName				"DIAGNOSTIC"
#define DiscName				"DISCOVERY"
#define ProtName				"VALUES"

#define Header(type)							    "OK" KEY_DELIMITER type KEY_DELIMITER
#define DiagnosticHeader(type)					    (String)Header(DiagName) + type + KEY_DELIMITER
#define DiscoveryHeader(type, id) 				    (String)Header(DiscName) + type + KEY_DELIMITER + id + KEY_DELIMITER
#define SensorName(id)							    (String)#id
#define SensorNamePort(id, port)                	(String)#id + PORT_DELIMITER + port
#define SensorDataHeader(type, id) 				    (String)Header(ProtName) + type + KEY_DELIMITER + id + KEY_DELIMITER

// enable short key names
#ifndef KVP_LONG_KEY_FORMAT

#define DictionaryHeader 						    "INIT DICTIONARY" KEY_DELIMITER
#define DictionaryValue(id)						    (String)id + KEY_VALUE_DELIMITER + #id + VALUE_DELIMITER
#define DictionaryValuePort(id, port)			    (String)id + PORT_DELIMITER + port + KEY_VALUE_DELIMITER + #id + PORT_DELIMITER + port + VALUE_DELIMITER
#define SensorDataValue(key, value) 			    (String)key + KEY_VALUE_DELIMITER + value + VALUE_DELIMITER
#define SensorDataValuePort(key, port, value) 		(String)key + PORT_DELIMITER + port + KEY_VALUE_DELIMITER + value + VALUE_DELIMITER

#else

#define SensorDataValue(key, value) 			    (String)(#key) + KEY_VALUE_DELIMITER + value + VALUE_DELIMITER
#define SensorDataValuePort(key, port, value) 		(String)(#key) + PORT_DELIMITER + port + KEY_VALUE_DELIMITER + value + VALUE_DELIMITER

#endif

enum Sensors : byte {
// weather Readings
	Temperature 		  	=   1
,	Pressure			  	=   2
,	Humidity			  	=   3
,	WindSpeed			  	=   4
,	WindDirection		  	=   5
,	WindGust			  	=   6
,	WindGustRef			  	=   7
,	RainTipCount		  	=   8
,	RainSecs			  	=   9
,	Solar				  	=  10
,	VoltageSolar		  	=  11
,	VoltageCapacitor		=  12
,	SoilLeaf			    =  13
,	UV					    =  14
,	SoilTemperature	  		=  15
,	SoilMoisture		  	=  16
,	LeafWetness			  	=  17
// techn. Readings
,	Channel				    =  20
,	Battery				    =  21
,	RSSI				    =  22
// Esp1wire Readings
, 	Device            		=  30
, 	Counter           		=  31
, 	Latch             		=  32
, 	Sense             		=  33
, 	FlipFlopQ         		=  34
, 	Voltage           		=  35
, 	Current           		=  36
, 	Capacity          		=  37
// m-e Vistadoor Readings
, 	Station           		=  80
, 	Command           		=  81
// diagnostic Readings
,	PacketDump				= 255
};


#endif  // _KVP_Sensors_h
