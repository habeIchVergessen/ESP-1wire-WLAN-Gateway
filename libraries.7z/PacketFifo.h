#ifndef _PACKETFIFO_H
#define _PACKETFIFO_H

#include <Arduino.h>

#define FIFO_SIZE 8
#define PACKET_LEN 10

// Davis Radio Data
struct __attribute__((packed)) RadioData {
    byte packet[PACKET_LEN];
    byte channel;
    byte rssi;
    int16_t fei;
    uint32_t delta;
};

// m-e Vistadoor Data
struct __attribute__((packed)) MeData {
    unsigned long prespanTime;
    byte station;
    byte command;
    unsigned long raw;
};

class PacketFifo {
public:
    // Davis Radio Data
    bool queue(byte* packet, byte channel, byte rssi, int16_t fei, uint32_t delta);
    RadioData* dequeue();
    // m-e Vistadoor Data
    bool queue(unsigned long prespanTimeMicros, byte stationRecv, byte commandRecv, unsigned long rawRecv);
    MeData* next();
    bool dequeue(MeData* meData);
    void flush();
    bool hasElements();
    byte queueLength();

private:
    RadioData packetFifo[FIFO_SIZE];
    MeData meFifo[FIFO_SIZE];
    byte packetIn, packetOut, qLen;
};

#endif
